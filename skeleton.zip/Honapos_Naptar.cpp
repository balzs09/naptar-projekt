#include "Honapos_Naptar.h"
#include <string>
 std::string honapok[] =
{ "Janu�r","Febru�r","M�rcius","�prilis","M�jus","J�nius","J�lius","Augusztus","Szeptember","Okt�ber","November","December" };

