#pragma once
#include <iostream>
#include "memtrace.h"
#include "Datum.h"
#include "Esemeny.h"
#include <stdexcept>
#include <sstream>

class Abs_Naptar
{
private:
	//A m�sol� konstruktor �s �rt�kad� oper�tor letilt�sa
	Abs_Naptar(const Abs_Naptar&) {}

	Abs_Naptar& operator=(const Abs_Naptar&)
	{
		return *this;
	}
protected:
	Esemeny* lefoglalt_esemenyek=nullptr;
	size_t lefoglalt_napok_szama=0;

public:

	//Az oszt�ly default konstruktora.
	Abs_Naptar()
	{
		lefoglalt_esemenyek=nullptr;
		lefoglalt_napok_szama=0;
	}

	//Destruktor. A dinamikusan foglalt adatok felszabadit�s��rt felel?s.
	~Abs_Naptar()
	{
		delete[] lefoglalt_esemenyek;
	}
	//Az �sszes nap sz�m�val t�r vissza. Az a szerepe, hogy ez publikusan is l�that� legyen.
	// Virtu�lis, mivel a napok sz�ma f�gg a napt�r tipus�t�l.
	virtual int capacity() const = 0;

	//A napt�r kiirat�sa. Virtu�lis mivel m�s form�ban irand� ki az �ves �s a h�napos napt�r.
	//param os- kimenet
	virtual void kiir(std::ostream& os = std::cout) const = 0;

	//Egy d�tum ellenorz�se, hogy lefoglalt-e vagy sem.
	//A f�ggv�ny true logikai �r�kkel t�r vissza, ha a d�tum m�r m�s esem�ny �ltal foglalt, false �rt�kkel ellenkezo esetben.
	//@param vizsgalando_date- A d�tum amirol szeretn�nk megtudni, hogy foglalt-e.
	 bool foglalt_e(const Datum& vizsgalando_date) const;

	 template<class E>
	 Esemeny Datum_Esemenye(const Datum& vizsgalando_date) const
	 {
		 for (const_iterator i = begin(); i != end(); i++)
		 {
			 if ((*i).get_lefoglalt_datum() == vizsgalando_date) return (*i);
		 }
		 std::stringstream hiba;
		 hiba << "**Helytelen d�tum**";
		 vizsgalando_date.datum_kiir(hiba);
		 hiba << "A d�tum m�g nincs lefoglalva semmilyen esem�ny �ltal sem.";
		 throw E(hiba.str());
	 }
	//A lefoglalt esem�nyek kiirat�sa.
	// Az esem�nyek a d�tumok id�rendi sorrendj�ben ker�lnek kiirat�sra
	// Az Esem�ny oszt�ly kiir� f�ggv�nye felhaszn�l�sra ker�l.
	//@param os- kimenet
	 void lefoglaltak_kiir(std::ostream& os=std::cout) const ;

     //T�rl�s est�n a foglalt_esemenzek fileba csak az adatokat irjuk be a k�nnyebb olvas�s �rdek�ben.
     void lefoglaltak_kiir_olvasashoz(std::ostream& os=std::cout) const ;
	// �j esem�ny hozz�ad�sa a lefoglalt esem�nyek list�j�hoz
	// Abban az esetben ha ez a d�tum m�r le van foglalva saj�t kiv�telt dob.
	// Az �j esem�nyt �gy sz�rja be, hogy az esem�nyek d�tum szerint n�vekv� sorrendben legyenek.
	// Ha az �j esem�ny minden esem�ny d�tum�n�l nagyobb, akkor a lista v�g�re ker�l.
	// M�s esetben az �j esem�ny be van sz�rva k�t d�tum k�z� majd a tov�bbi esem�nyek az eggyel kisebb index� esem�nyt kapj�k meg.
	//@param uj_esemeny- A lefoglalt esem�nyek list�j�hoz hozz�adand� esem�ny.

	 template<class E>
	 void foglalas(const Esemeny& uj_esemeny)
	 {
		 size_t uj_pozicio=lefoglalt_napok_szama;
		 if (foglalt_e(uj_esemeny.get_lefoglalt_datum()) == true)
		 {
			 std::stringstream  hiba;
			 hiba << "**Foglal�shiba**- A(z)";
			 uj_esemeny.get_lefoglalt_datum().datum_kiir(hiba);
			 hiba << " d�tum m�r foglalt  m�s esem�ny �ltal";
			 throw E(hiba.str());
		 }
		Esemeny* uj_esemenyes = new Esemeny[lefoglalt_napok_szama + 1];
		for (size_t i = 0; i< lefoglalt_napok_szama; i++)
		{
			if (lefoglalt_esemenyek[i].get_lefoglalt_datum() <= uj_esemeny.get_lefoglalt_datum())
				uj_esemenyes[i] = lefoglalt_esemenyek[i];
			else
			{
				uj_pozicio = i;
				break;
			}
		}
		uj_esemenyes[uj_pozicio] = uj_esemeny;
		for (size_t j = uj_pozicio; j < lefoglalt_napok_szama; j++)
			uj_esemenyes[j + 1] = lefoglalt_esemenyek[j];
		lefoglalt_napok_szama++;
		delete[]lefoglalt_esemenyek;
		lefoglalt_esemenyek = uj_esemenyes;
	 }

	//Esem�y t�rl�se a lefoglalt esem�nyek list�j�b�l
	// Ha nem tal�lhat� meg a lefoglalt esem�nyek k�z�tt a param�terk�nt megadott esem�ny saj�t kiv�telt dob.
	// Miut�n megtal�ta a f�ggv�ny a t�rlend� esem�nyt, addig a pozici�ig az esem�nyeket lefoglalja.
	// A t�r�lt pozic�t�l az  esem�nyek elcsusztat�sa �ltal megkapjuk az �j list�t.
	// A f�ggv�nye �sszehasonlitja a list�ban l�v? esem�nyeket �s egyez�s eset�n t�rli
	template<class E>
	void torles(Esemeny& torlendo_esemeny)
	{
		size_t torlendo_pozicio =lefoglalt_napok_szama ;//A t�r�lt elem pozici�j�nak megtal�l�s�hoz sz�ks�ges.
		for (size_t i = 0; i < lefoglalt_napok_szama; i++)
		{
			if (lefoglalt_esemenyek[i] == torlendo_esemeny)
			{
				torlendo_pozicio = i;
				break;
			}
		}
		if (torlendo_pozicio==lefoglalt_napok_szama)//Azt jelenti nincs ilyen esem�ny m�g lefoglalva
		{
			std::stringstream  hiba;
			hiba << "**T�rl�sshiba**- A(z)";
			torlendo_esemeny.esemeny_kiir(hiba);
			hiba << " esem�ny  m�g nincs lefoglalva, igy t�r�lni se lehet.";
			throw E(hiba.str());
		}

		Esemeny* torolt_esemenyes = new Esemeny[lefoglalt_napok_szama -1];
		for (size_t i = 0; i < torlendo_pozicio; i++)
			torolt_esemenyes[i] = lefoglalt_esemenyek[i];
		for (size_t j = torlendo_pozicio; j < lefoglalt_napok_szama - 1; j++)
			torolt_esemenyes[j] = lefoglalt_esemenyek[j + 1];
		lefoglalt_napok_szama--;
		delete[]lefoglalt_esemenyek;
		lefoglalt_esemenyek = torolt_esemenyes;
	}

	//A kosnstans iter�tor oszt�ly el?redeklar�l�sa
	class const_iterator;
	//Iter�tor l�zrehoz�sa �s az els? elemre �llit�sa
	const_iterator begin() const{ return  const_iterator(*this); }

	//Iter�tor l�trehoz�sa �s a az utols� elem ut�nra �llit�sa
	const_iterator end()  const{ return const_iterator(*this, lefoglalt_napok_szama); }
	class const_iterator
	{
	private:
		//pointer az aktu�lis �s utols� ut�ni elemre
		const Esemeny* p_aktualis, * p_utolso;
	public:
		//Default konstruktor
		const_iterator() :p_aktualis(nullptr), p_utolso(nullptr) {}
		//Param�teres konstruktor
		const_iterator(const Abs_Naptar& naptar, size_t idx = 0)
			:p_aktualis(naptar.lefoglalt_esemenyek + idx), p_utolso(naptar.lefoglalt_esemenyek + naptar.lefoglalt_napok_szama) {}
		//Iter�tor preinkremens n�vel�se
		const_iterator& operator++()
		{
			if (p_aktualis != p_utolso)
			{
				++p_aktualis;
			}
			return *this;
		}
		//Iter�tor posztinkremens n�vel�se
		const_iterator operator++(int)
		{
			const_iterator tmp = *this;
			operator++();
			return tmp;
		}
		//Iter�torok �sszehasonlit�sa
		bool operator!=(const const_iterator& masik) const {
			return p_aktualis != masik.p_aktualis;
		}
	   //Iter�tor indirekci�ja
	   //Ha az iter�tor a t�r v�g�n van std::out of range hiba�zenetet k�ld.
		const Esemeny& operator*() const
		{
			if (p_aktualis == p_utolso)
			{
				throw std::out_of_range("Iter�tor a v�g�n van.");
			}
			return *p_aktualis;
		}
	};
	//A lista egy elem�nek visszat�rit�se sorsz�ma alapj�n
	//Ha nem megfelelo az index, kiv�telt dob az E oszt�lyba.
	template<class E>
	Esemeny getesemeny(size_t i)
	{
		if (i < 1)
		{
			std::stringstream  hiba;
			hiba << "**Indexhiba**- Nincs elem az els� elem el?tt";
			throw E(hiba.str());
		}
		if(i>lefoglalt_napok_szama)
		{
			std::stringstream  hiba;
			hiba << "**Indexhiba**- Nincs " << i << " esem�ny lefoglalva csak " << lefoglalt_napok_szama;
			throw E(hiba.str());
		}
		return lefoglalt_esemenyek[i-1];
	}
	//Az fs-ben szerepl� lefoglalt napokat beolvassa �s lefoglalja.
    //�gy val�s�that� meg , hogy a r�gebben lefoglalt napok megmaradjanak.
     template<class E>
     void foglalas_olvasas_file(std::istream& is )
     {
         if(is)
        {
                 while(is)
                 {
                     Esemeny lefoglalt_esemeny;
                     std::ostringstream alkiiro;//Ebben az esetben nem sz�ks�ges a kiir�s ez�rt van haszn�lva egy n�ma output.
                     lefoglalt_esemeny.esemeny_beolvas(is,alkiiro);
                     foglalas<E>(lefoglalt_esemeny);
                  }
            std::stringstream hiba;
            hiba<<"**F�jlhiba**-Nem siker�lt a f�jlt beolvasni";
        }


     }

};

